import React from "react"
import {Button, MenuIcon, CardHeader,Typography} from "@gui/material"
import {AddCircleIcon} from "@gui/icons-material"
function Banner ({setOpenDialog, setEventAdded}) {
    return (
        <CardHeader
            sx = {{textAllign : "center", bgcolor : "dark", color : "while"}}
            eventTitle = {
                <Typography
                    variant = "h5"
                    component = "div"
                    sx = {{display : "flex", align : "center", flexWrap : "wrap"}}>
                    <MenuIcon fontsize = "large" />
                    <span>FRAMEWORKS</span>
                </Typography>
            }
            eventAction = {
                <Button variant="contained" onclick = {() => {
                    setEventAdded(true);
                    setOpenDialog(true);
                }}
                >
                    <AddCircleIcon fontsize = "small" sx = {{mr : 1}}>
                    </AddCircleIcon>
                    <Typography>ADD</Typography>
                </Button>
            }
        />
    );
}
export default Banner