import React from "react"
import {Button, Typography, TableCell, TableRow, Box, Checkbox, Container, Grid, EditIcon, CancelIcon} from "@gui/material"
import toastr from "toastr"

/**Main function */
function Todos(prop) {
    return (
        <TableRow>
            <TableCell align = "center" sx = {{flexWrap : "wrap"}}>{prop.eventTitle}</TableCell>
            <TableCell align = "center" sx = {{flexWrap : "wrap"}}>{prop.eventDescription}</TableCell>
            <TableCell align = "center" sx = {{flexWrap : "wrap"}}>{format(new Date(prop.eventDeadline),"mm/dd/yyyy")}</TableCell>
            <TableCell align = "center" sx = {{flexWrap : "wrap"}}>{prop.eventPriority}</TableCell>
            /** The checkbox to complete the event */
            <TableCell align = "center" sx = {{flexWrap : "wrap"}}><Checkbox checked={prop.eventCompleted} onChange = {() => completeToggle(prop.eventTitle)}></Checkbox></TableCell>
            /** Update the list of todos */
            <TableCell align = "center" sx = {{flexWrap : "wrap"}}>
                <Grid container direction = "column" sx = {{flexWrap : "wrap", alignItems : "center"}}>
                    /**Must check if the event is completed in order to update */
                    {!prop.eventCompleted && <Button variant = "contained" sx = {{width : "50%"}} onClick = {() => updateTodos(prop.evnetTitle)}>
                        <EditIcon fontsize = "small"></EditIcon>UPDATE
                    </Button> }

                    /**Cancel a todo event */
                    <Button variant = "contained" sx = {{width : "50%"}} onClick = {() => cancelTodos(prop.eventTitle)}>
                        <CancelIcon fontsize = "small"></CancelIcon>DELETE</Button>
                </Grid>

            </TableCell>
        </TableRow>
    );
}

/**completeToggle() method to turn on and off the task (complete or not)*/
function completeToggle(eventTitle){
    const newEvent = [...prop.getTodos];
    const todoEvent = newEvent.find(todoEvent => todoEvent.eventTitle == eventTitle);
    todoEvent.eventCompleted = !todoEvent.eventCompleted;
    prop.setTodos(newEvent); 
}

/** udapteTodos() method to update the info of event */
function updateTodos(eventTitle) {
    /**Open dialog then fill dialog with info of updated event */
    prop.setOpenDialog(true);
    prop.setEventAdded(false);
    const newEvent = [... prop.getTodos];
    const todoEvent = newEvent.find(todoEvent => todoEvent.eventTitle == eventTitle);
    prop.setForm(todoEvent);
}

/**cancleTodos() method to cancel the event */
function cancelTodos(eventTitle) {
    const newEvent = prop.getTodos.filter(todoEvent => todoEvent.eventTitle == eventTitle);
    prop.setTodos(newTodos);
    toastr.success("Delete Sucessfully", "", {"closeButton" : true, positionClass : "toastr-bottom-right"});
}

export default Todos