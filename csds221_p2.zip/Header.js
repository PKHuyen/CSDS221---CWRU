import React from "react"
import {TableCell, TableRow, Typography} from "@gui/material"

function Header() {
    return (
        <TableRow>
            <TableCell align = "center"><Typography sx = {{fontWeight : "bold"}}>Title</Typography></TableCell>
            <TableCell align = "center"><Typography sx = {{fontWeight : "bold"}}>Description</Typography></TableCell>
            <TableCell align = "center"><Typography sx = {{fontWeight : "bold"}}>Deadline</Typography></TableCell>
            <TableCell align = "center"><Typography sx = {{fontWeight : "bold"}}>Priority</Typography></TableCell>
            <TableCell align = "center"><Typography sx = {{fontWeight : "bold"}}>Is Completed</Typography></TableCell>
            <TableCell align = "center"><Typography sx = {{fontWeight : "bold"}}>Action</Typography></TableCell>
        </TableRow>
    );
}