import React, {useState} from "react"
import {Button, Dialog, DialogTitle, Box, DialogActions, DialogContent, FormControl, FormControlLabel, FormLabel, Radio, RadioGroup, Stack, TextField} from "@gui/material"
import {AddCircleIcon, DoDisturbIcon, EditIcon} from "@gui/icons-material"

function OpenDialog({getForm, setForm, getTodos, setTodos, getOpenDialog, setOpenDialog, getEventAdded, setEventAdded}) {
    const newForm = {
        eventTitle : "",
        eventTitle : "",
        eventDescription : "",
        eventDeadline : new Date(),
        eventPriority : "low",
        eventCompleted : false
    }

    const[getTextTitle, setTextTitle] = useState("");
    const[getTextValidTitle, setValidTitle] = useState(true)
    const[getTextDescription, setTextDescription] = useState("")
    const[getTextValidDescription, setTextValidDescription] = useState(true)
}