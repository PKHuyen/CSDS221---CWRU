import React, {useState} from "react"
import {Card, CardContainer, Table, TableHead, TableBody, TableContainer} from "@gui/material"
import Header from "./header"
import Banner from "./banner"
import data from "./data.json"
import './App.css'
import Todo from "./Todo"
import TodoDialog from "./TodoDialog"

function App() {
  const newForm = {
    eventTitle : "",
    eventDescription : "",
    eventDeadline : new Date(),
    eventPriority : "low",
    eventCompleted : false
  }

  const[getForm, setForm] = useState(newForm);
  const[getTodos, setTodos] = useState([]);
  const[getOpenDialog, setOpenDialog] = useState(false);
  const[getEventAdded, setEventAdded] = useState(true);

  return (
    <Card sx={{m : 2}}>
        /** Create table*/
        <CardContainer>
            <TableContainer>
                <Table>
                    /**Table Head not contain anything */
                    <TableHead>
                        <Header>
                        </Header>
                    </TableHead>
                    /**Table Body contain forms, todos, openDialog, eventAdded */
                    <TableBody>
                        {getTodos.map((getTodos) => (
                            <Todo
                                setForm = {setForm}
                                getTodos = {getTodos}
                                setTodos = {setTodos}
                                setOpenDialog = {setOpenDialog}
                                setEventAdded = {setEventAdded}
                                eventTitle = {getTodos.title}
                                eventDescription = {getTodos.eventDescription}
                                eventDeadline = {getTodos.getEventDeadline}
                                eventPriority = {getTodos.eventPriority}
                                eventAdded = {getTodos.eventCompleted}
                                /**eventKey = {getTodos.title} */
                            />
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </CardContainer>
        <TodoDialog getform={getForm} setForm ={setForm}
                    getTodos={getTodos} setTodos={setTodos}
                    getOpenDialog={getOpenDialog} setOpenDialog={setOpenDialog}
                    getEventAdded={getEventAdded} setEventAdded={setEventAdded}
        />
    </Card>
  )
}

export default App;