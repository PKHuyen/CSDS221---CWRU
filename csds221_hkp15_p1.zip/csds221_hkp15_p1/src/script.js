$(document).ready(function() {
//reset button
 $('#clearForm').click(function() {
    $("#messageInput").text("");
    toastr.info("Form cleared");
  });
});
// submit button
 $("#submitForm").click(function(e) {
      e.preventDefault();
      let valid = true;
      let validation = [true, true, true, true, true, true];
      const fields = ["#usernameInput", "#firstNameInput", "#lastNameInput", "#phoneInput", "#faxInput", "#emailInput"];
      const fieldNames = ["Username", "First Name", "Last Name", "Phone Number", "Fax", "Email"];
      
      for (let i = 0; i < 6; i++) {
        checkInput(fields[i], i);
      }
      
      function checkInput(element, count) {
        if ($(element).val() == '') {
          $(element).addClass('is-invalid');
          validation[count] = false;
        } else {
          $(element).removeClass('is-invalid');
          validation[count] = true;
        }
      }
      
      let error = 'Fill out these fields: ';
      for (let i = 0; i < 6; i++) {
        if (!validation[i]) {
          error += "</br>" + fieldNames[i];
          valid = false;
        }
      }
   
      const cost = $("#outputCost").val()
      if (cost <= 0) {
        toastr.error('Cost is invalid.');
        $("#cost").addClass("is-invalid");
        valid = false;
      } else {
        $("#cost").removeClass("is-invalid");
      }
      
      if (!valid)
        toastr.error(error);
      else
        toastr.success('Successfully submitted!');
    });

$(document).ready(function(){
  const updateSchedule = function() {
    const checkIn = $("#checkinInput").val();
    const checkOut = $("#checkoutInput").val();
    const num = Number($("#adultInput").val());
    
    if (!(checkIn && checkOut)) return;
    const momentCheckIn = moment(checkIn, "YYYY-MM-DD");
    const momentCheckOut = moment(checkOut, "YYYY-MM-DD");
    const dayDifference = momentCheckOut.diff(momentCheckIn, "days");
    
    $("#outputDays").val(dayDifference);
    $("#outputCost").val(num * dayDifference * 150);
  }
  
  $("#adultInput").change(updateSchedule);
  $("#checkinInput").change(updateSchedule);
  $("#checkoutInput").change(updateSchedule);
});
