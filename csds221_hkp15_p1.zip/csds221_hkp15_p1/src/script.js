//Calculate the cost and number of days
$(document).ready(function(){
  const updateSchedule = function() {
    const checkIn = $("#checkinInput").val();
    const checkOut = $("#checkoutInput").val();
    const num = Number($("#adultInput").val());
    
    if (!(checkIn && checkOut)) return;
    const momentCheckIn = moment(checkIn, "YYYY-MM-DD");
    const momentCheckOut = moment(checkOut, "YYYY-MM-DD");
    const dayDifference = momentCheckOut.diff(momentCheckIn, "days");
    
    $("#outputDays").val(dayDifference);
    $("#outputCost").val(num * dayDifference * 150);
  }
  
  $("#adultInput").change(updateSchedule);
  $("#checkinInput").change(updateSchedule);
  $("#checkoutInput").change(updateSchedule);
});

//reset button. Clear all data in form
$(document).ready(function() {
 $('#clearForm').click(function() {
    $("#messageInput").text("");
    toastr.info("Form cleared");
  });
});

// submit button. Must check all boxes if it's valid. Use array to check each of the box and return if there's an error
 $("#submitForm").click(function(e) {
      e.preventDefault();
      let check = true;
      let valid = [true, true, true, true, true, true];
      const idName = ["#usernameInput", "#firstNameInput", "#lastNameInput", "#phoneInput", "#faxInput", "#emailInput"];
      const name = ["Username", "First Name", "Last Name", "Phone Number", "Fax", "Email"];
      //For each box, check the error
      for (let i = 0; i < 6; i++) {
        checkInput(idName[i], i);
      }
      function checkInput(element, count) {
        if ($(element).val() == '') {
          $(element).addClass('is-invalid');
          valid[count] = false;
        } 
        else {
          $(element).removeClass('is-invalid');
          valid[count] = true;
        }
      }
      
      //Check the error, if there is, show with toastr
      let error = 'Error: ';
      for (let i = 0; i < 6; i++) {
        if (!valid[i]) {
          error += "</br>" + name[i];
          check = false;
        }
      }
   
      // Check the cost error, if its not positive, show with toastr
      const cost = $("#outputCost").val()
      if (cost <= 0) {
        toastr.error('Invalid cost');
        $("#cost").addClass("is-invalid");
        check = false;
      } 
      else {
        $("#cost").removeClass("is-invalid");
      }
      
      //Highlight error 
      if (!check) {
        toastr.error(error);
      }
      //Success
      else {
        toastr.success('Successfully submitted!');
      }
 });


